import java.util.Scanner;

public class H {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        for(int i=0; i < 5; i++){

            int score = Integer.parseInt(sc.nextLine());
            switch(score / 10) {
                case 10:
                    System.out.println("A+");break;
                case 9:
                    System.out.println("A");break;
                case 8:
                    System.out.println("B");break;
                case 7:
                    System.out.println("C");break;
                case 6:
                    System.out.println("D");break;
                default:System.out.println("E");break;
            }
        }

    }
}
